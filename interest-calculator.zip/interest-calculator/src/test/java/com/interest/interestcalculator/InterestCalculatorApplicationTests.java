package com.interest.interestcalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterestCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}

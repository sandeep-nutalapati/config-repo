package com.interest.interestcalculator.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.interest.interestcalculator.dto.CustomerInterest;

public class CustomerInterestRowMapper implements RowMapper<CustomerInterest> {

	@Override
	public CustomerInterest mapRow(ResultSet resultSet, int arg1) throws SQLException {
		CustomerInterest cust = new CustomerInterest();
		cust.setCustId(resultSet.getInt("custid"));
		cust.setCustName(resultSet.getString("custname"));
		cust.setPrinciple(resultSet.getString("principle"));
		cust.setTenure(resultSet.getInt("tenure"));
		cust.setStatus(resultSet.getString("status"));
		return cust;
	}
}

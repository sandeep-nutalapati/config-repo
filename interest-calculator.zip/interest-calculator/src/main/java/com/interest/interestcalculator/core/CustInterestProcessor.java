package com.interest.interestcalculator.core;

import java.math.BigDecimal;

import org.springframework.batch.item.ItemProcessor;

import com.interest.interestcalculator.dto.CustomerInterest;

public class CustInterestProcessor implements ItemProcessor<CustomerInterest, CustomerInterest> {

	@Override
	public CustomerInterest process(CustomerInterest item) throws Exception {
		// TODO Auto-generated method stub
		BigDecimal totalAmt=new BigDecimal(item.getPrinciple()).add(new BigDecimal(item.getPrinciple()).multiply(new BigDecimal(item.getTenure())).multiply(new BigDecimal(12)).divide(new BigDecimal(100)));
		item.setTotalAmount(totalAmt);
		return item;
	}

}

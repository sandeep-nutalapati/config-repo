package com.interest.interestcalculator.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.interest.interestcalculator.dto.CustomerInterest;

public class CustInterestWriter implements ItemWriter<CustomerInterest> {

	@Autowired
	JdbcTemplate template;
	
	@Transactional
	@Override
	public void write(List<? extends CustomerInterest> items) throws Exception {

		// Batch update was implemented using spring jdbc template
		this.template.batchUpdate(
                "update customercompinterest set compamt=? where custid = ?",
                new BatchPreparedStatementSetter() {

                    public void setValues(PreparedStatement ps, int i)
						throws SQLException {
                        ps.setBigDecimal(1, items.get(i).getTotalAmount());
                        ps.setLong(2, items.get(i).getCustId());
                    }

                    public int getBatchSize() {
                        return 100;
                    }

                });
		
	}

}

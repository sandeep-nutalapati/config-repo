package com.interest.interestcalculator.listeners;

import org.springframework.batch.core.SkipListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.interest.interestcalculator.dto.CustomerInterest;

@Component
public class JobListener implements SkipListener<CustomerInterest,CustomerInterest>{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public void onSkipInProcess(CustomerInterest arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
		String updateQuery = "update customerinterest set status = ? where custid = ?";
		jdbcTemplate.update(updateQuery, "N", arg0.getCustId());
		
	}

	@Override
	public void onSkipInRead(Throwable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSkipInWrite(CustomerInterest arg0, Throwable arg1) {
		String updateQuery = "update customerinterest set status = ? where custid = ?";
		jdbcTemplate.update(updateQuery, "N", arg0.getCustId());
		
	}

}

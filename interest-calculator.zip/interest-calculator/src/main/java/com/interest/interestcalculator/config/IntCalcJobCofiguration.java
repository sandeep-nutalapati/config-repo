package com.interest.interestcalculator.config;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.integration.async.AsyncItemProcessor;
import org.springframework.batch.integration.async.AsyncItemWriter;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.support.MySqlPagingQueryProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.interest.interestcalculator.core.CustInterestProcessor;
import com.interest.interestcalculator.core.CustInterestWriter;
import com.interest.interestcalculator.dto.CustomerInterest;
import com.interest.interestcalculator.mapper.CustomerInterestRowMapper;

@Configuration
public class IntCalcJobCofiguration {

	@Autowired
	private JobBuilderFactory jobFactory;

	@Autowired
	private StepBuilderFactory stepFactory;

	@Autowired
	public DataSource dataSource;

	@Bean
	public Job customerReportJob() {
		return jobFactory.get("customerReportJob").start(chunkStep()).build();
	}

	@Bean
	public Step chunkStep() {
		return stepFactory.get("taskletStep").<CustomerInterest, Future<CustomerInterest>>chunk(10).
				reader(pagingItemReader())
				.processor(processor()).writer(writer())
				.faultTolerant()
				.skipLimit(1000)
				.skip(Exception.class)
				.build();
	}

	@Bean
	public JdbcPagingItemReader<CustomerInterest> pagingItemReader() {
		JdbcPagingItemReader<CustomerInterest> reader = new JdbcPagingItemReader<>();
		reader.setDataSource(this.dataSource);
		reader.setFetchSize(10);
		reader.setRowMapper(new CustomerInterestRowMapper());
		MySqlPagingQueryProvider queryProvider = new MySqlPagingQueryProvider();
		queryProvider.setSelectClause("custid, custname, principle, tenure,status");
		queryProvider.setFromClause("from customer");
		Map<String, Order> sortKeys = new HashMap<>(1);
		sortKeys.put("custid", Order.ASCENDING);
		queryProvider.setSortKeys(sortKeys);
		reader.setQueryProvider(queryProvider);
		return reader;
	}

	@Bean
	private AsyncItemProcessor<CustomerInterest, CustomerInterest> processor() {
		AsyncItemProcessor<CustomerInterest, CustomerInterest> processor=new AsyncItemProcessor<>();
		processor.setDelegate(new CustInterestProcessor());
		return processor;
	}

	@Bean
	private ItemWriter<Future<CustomerInterest>> writer() {
		AsyncItemWriter<CustomerInterest> asyncItemWriter = new AsyncItemWriter<>();
		asyncItemWriter.setDelegate( new CustInterestWriter());
		return asyncItemWriter;
	}

	@Bean(name = "asyncExecutor")
	public TaskExecutor getAsyncExecutor() {
		ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
		executor.setCorePoolSize(10);
		executor.setMaxPoolSize(20);
		executor.setQueueCapacity(10);
		executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		executor.setThreadNamePrefix("AsyncExecutor-");
		return executor;
	}

}

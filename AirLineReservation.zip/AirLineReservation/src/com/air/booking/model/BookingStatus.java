package com.air.booking.model;

public enum BookingStatus {
	
	BOOKED,
	AVAILABLE;

}

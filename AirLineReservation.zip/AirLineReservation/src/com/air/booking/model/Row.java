package com.air.booking.model;

import java.util.List;
import java.util.stream.Collectors;

public class Row {

	private List<Ceat> ceats;

	public Row() {
	}

	public Row(List<Ceat> ceats) {
		this.ceats = ceats;
	}
	
	public long getAvaialableCount() {
		return ceats.stream().filter(ceat->ceat.getStatus().equals(BookingStatus.AVAILABLE)).count();
	}
	
	public List<Ceat> getAvaialable() {
		return ceats.stream().filter(ceat->ceat.getStatus().equals(BookingStatus.AVAILABLE)).collect(Collectors.toList());
	}

	public List<Ceat> getCeats() {
		return ceats;
	}

	public void setCeats(List<Ceat> ceats) {
		this.ceats = ceats;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ceats == null) ? 0 : ceats.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Row other = (Row) obj;
		if (ceats == null) {
			if (other.ceats != null)
				return false;
		} else if (!ceats.equals(other.ceats))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Row [ceats=" + ceats + "]";
	}

}

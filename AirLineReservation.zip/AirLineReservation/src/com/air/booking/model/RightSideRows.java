package com.air.booking.model;

import java.util.List;

public class RightSideRows {
	
	//assuming all right side rows row-number starts with R
	String rowNumber;
	
	List<Row> rightSideRows;
	
	
	public RightSideRows() {
	}

	public RightSideRows(String rowNumber, List<Row> rightSideRows) {
		this.rowNumber = rowNumber;
		this.rightSideRows = rightSideRows;
	}

}

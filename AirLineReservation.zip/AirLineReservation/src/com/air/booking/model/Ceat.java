package com.air.booking.model;

public class Ceat {

	private String ceatNumber;
	private BookingStatus status=BookingStatus.AVAILABLE;
	
	public Ceat(String ceatNumber) {
		this.ceatNumber = ceatNumber;
	}

	public String getCeatNumber() {
		return ceatNumber;
	}

	public void setCeatNumber(String ceatNumber) {
		this.ceatNumber = ceatNumber;
	}

	public BookingStatus getStatus() {
		return status;
	}

	public void setStatus(BookingStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Ceat [ceatNumber=" + ceatNumber + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ceatNumber == null) ? 0 : ceatNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ceat other = (Ceat) obj;
		if (ceatNumber == null) {
			if (other.ceatNumber != null)
				return false;
		} else if (!ceatNumber.equals(other.ceatNumber))
			return false;
		return true;
	}
	
}

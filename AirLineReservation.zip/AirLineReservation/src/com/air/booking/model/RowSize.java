package com.air.booking.model;

public enum RowSize {
	LEFTSIZE(2), RIGHT(2), MIDDLE(3);

	private int size;

	RowSize(int size) {
		this.size = size;
	}

	public int getSize() {
		return size;
	}

}

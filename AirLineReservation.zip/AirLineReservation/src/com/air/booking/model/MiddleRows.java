package com.air.booking.model;

import java.util.List;

public class MiddleRows {
	
	//assuming all middle rows row-number starts with M
	String rowNumber;
	
	List<Row> middleRows;
	
	
	public MiddleRows() {
	}

	public MiddleRows(String rowNumber, List<Row> middleRows) {
		super();
		this.rowNumber = rowNumber;
		this.middleRows = middleRows;
	}

}

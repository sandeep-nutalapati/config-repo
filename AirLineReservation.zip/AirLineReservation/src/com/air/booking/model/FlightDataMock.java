package com.air.booking.model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class FlightDataMock {
	
	
	public static Flight createFlight(String flightNumber) {
		
		return createFlight( flightNumber, 10);
	}
	
	public static Flight createFlight(String flightNumber,int rows) {
		List<Row> left=new ArrayList<>();
		addRows(left,rows,"L");
		List<Row> middle=new ArrayList<>();
		addMiddleRows(middle,rows,"M");
		List<Row> right=new ArrayList<>();
		addRows(left,rows,"R");
		return new Flight(flightNumber,flightNumber,left,middle,right);
		
	}

	//creating middle rows
	private static void addMiddleRows(List<Row> middle, int rows, String suffix) {
		Stream.iterate(0, n->n+1).limit(rows).forEach(rowNum->{
			Ceat ceat1=new Ceat(suffix+rowNum+1);
			Ceat ceat2=new Ceat(suffix+rowNum+2);
			Ceat ceat3=new Ceat(suffix+rowNum+3);
			List<Ceat> ceats=new ArrayList<>();
			ceats.add(ceat1);
			ceats.add(ceat2);
			ceats.add(ceat3);
			Row row=new Row(ceats);
			middle.add(row);
		});
		
	}

	//creating side rows and ceats
	private static void addRows(List<Row> side, int rows, String suffix) {
		Stream.iterate(0, n->n+1).limit(rows).forEach(rowNum->{
			Ceat ceat1=new Ceat(suffix+rowNum+1);
			Ceat ceat2=new Ceat(suffix+rowNum+2);
			List<Ceat> ceats=new ArrayList<>();
			ceats.add(ceat1);
			ceats.add(ceat2);
			Row row=new Row(ceats);
			side.add(row);
		});
		
	}

}

package com.air.booking.model;

import java.util.List;

public class LeftSideRows {
	
	//assuming left side row number starts with L
	String rowNumber;
	
	List<Row> leftRows;
	
	

	public LeftSideRows() {
	}

	public LeftSideRows(String rowNumber, List<Row> leftRows) {
		super();
		this.rowNumber = rowNumber;
		this.leftRows = leftRows;
	}
	
	
	

	
	

}

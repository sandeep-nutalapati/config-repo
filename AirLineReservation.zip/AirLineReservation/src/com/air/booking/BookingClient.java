package com.air.booking;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.air.booking.model.Ceat;
import com.air.booking.model.Flight;
import com.air.booking.model.FlightDataMock;
import com.air.booking.model.Row;
import com.air.booking.model.RowSize;

public class BookingClient {
	
	
	public static void main(String[] args) {
		
		int noOfCeats=5;
		
		Flight flight1=FlightDataMock.createFlight("AB101", 15);
		
		Flight flight2=FlightDataMock.createFlight("EF102", 20);
		
		bookCeats(flight1,noOfCeats);
		
	}

	private static void bookCeats(Flight flight, int noOfCeats) {
		List<Ceat> bookedCeats = null;
		if (noOfCeats <= RowSize.LEFTSIZE.getSize())
			bookedCeats = searchLeftOrRight(flight, noOfCeats);

		else if (noOfCeats <= RowSize.MIDDLE.getSize()) {
			bookedCeats = searchMiddle(flight, noOfCeats);
		}

		if (bookedCeats == null || bookedCeats.isEmpty()) {
			bookedCeats=randomSearch(flight, noOfCeats);
		}
		
		if(bookedCeats == null || bookedCeats.isEmpty()) {
			System.out.println("Ceats not available");
		}else {
			System.out.println("Booked Ceats");
			System.out.println(bookedCeats);
		}

	}

	private static List<Ceat> randomSearch(Flight flight, int noOfCeats) {
		List<Row> allRows=new ArrayList<>();
		allRows.addAll(flight.getLeftRows());
		allRows.addAll(flight.getRight());
		allRows.addAll(flight.getMiddle());
		
		List<Ceat> availableRequiredCeats=allRows.stream().map(Row::getAvaialable).flatMap(List::stream).limit(noOfCeats).collect(Collectors.toList());
		if(availableRequiredCeats.size()==noOfCeats) {
			return availableRequiredCeats;
		}
		return null;
	}

	private static List<Ceat> searchMiddle(Flight flight,int noOfSeats) {

		
		List<Ceat> bookedSeats=flight.getMiddle().stream().filter(row->row.getAvaialableCount()>=noOfSeats).map(Row::getAvaialable).flatMap(List::stream).limit(noOfSeats).collect(Collectors.toList());
		return bookedSeats;
	
		
	}

	private static List<Ceat> searchLeftOrRight(Flight flight,int noOfSeats) {
		
		List<Ceat> bookedSeats=flight.getLeftRows().stream().filter(row->row.getAvaialableCount()>=noOfSeats).map(Row::getAvaialable).flatMap(List::stream).limit(noOfSeats).collect(Collectors.toList());
		if(bookedSeats.isEmpty()) {
			bookedSeats=flight.getLeftRows().stream().filter(row->row.getAvaialableCount()>=noOfSeats).map(Row::getAvaialable).flatMap(List::stream).limit(noOfSeats).collect(Collectors.toList());
		}
		return bookedSeats;
	}

}
